﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VenderManagementConsole
{
    internal class Vendor
    {
        public int VendorId { get; set; }
        public string VendorLongName { get; set; }
        public string VendorCode { get; set; }
        public string VendorPhoneNumber { get; set; }
        public string VendorEmail { get; set; }
        public DateTime VendorCreatedOn { get; set; }
        public bool IsActive { get; set; }

        

        #region methods
        public string AddVendor(Vendor vendor,List<Vendor> vendorList)
        {
            //Checking if this particular vendor is already there in list
            
            vendorList.Add(vendor);
            return "Vendor Added Successfully";
           
        }
        #endregion

    }
}
