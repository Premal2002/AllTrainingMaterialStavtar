﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VenderManagementConsole
{
    internal class Invoice
    {
        public  int InvoiceId { get; set; }
        public  int InvoiceNumber { get; set; }
        public int InvoiceCurrencyId { get; set; }
        public int VendorId { get; set; }
        public double InvoiceAmount { get; set; }
        public DateTime InvoiceReceivedDate { get; set; }
        public DateTime InvoiceDueDate { get; set; }
        public bool IsActive { get; set; }
    }
}
