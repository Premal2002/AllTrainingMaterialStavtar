﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Numerics;
using System.Reactive.Linq;
using System.Text.Json;
using VendorManagementAPI.DTO;
using VendorManagementAPI.Models;

namespace VendorManagementAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InvoiceController : ControllerBase
    {
        private readonly VendorManagementContext _context;


        public InvoiceController(VendorManagementContext context)
        {
            this._context = context;
        }

        [HttpGet]
        public IActionResult GetAllInvoices()
        {
            try
            {
                var vList = _context.Invoices.ToList();
                return Ok(vList);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpGet("getInvoiceByNumber/{iNumber}")]
        public IActionResult GetInvoiceByNumber(int iNumber)
        {
            try
            {
                Invoice v = _context.Invoices.Where(c => c.InvoiceNumber == iNumber).SingleOrDefault();
                if (v != null)
                    return Ok(v);
                else
                    throw new Exception("Invoice with code " + iNumber + " is not present");
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpGet("getByVendor/{vCode}")]
        public IActionResult GetAllInvoicesByVendorCode(string vCode)
        {
            try
            {
                //var customList = JsonSerializer.Deserialize<List<Invoice>>(list); // never used
                int vId = _context.Vendors.Where(v => v.VendorCode == vCode).SingleOrDefault().VendorId;
                var iList = _context.Invoices.Where(i => i.VendorId == vId);
                return Ok(iList);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpGet("getByCurrency/{cCode}")]
        public IActionResult GetAllInvoicesByCurrencyCode(string cCode)
        {
            try
            {
                //var customList = JsonSerializer.Deserialize<List<Invoice>>(list); //never used

                int cId = _context.Currencies.Where(v => v.CurrencyCode == cCode).SingleOrDefault().CurrencyId;
                var iList = _context.Invoices.Where(i => i.CurrencyId == cId);
                return Ok(iList);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpGet("getFilteredInvoices/{cCode}/{vCode}")]
        public IActionResult GetFilteredInvoices(string cCode,string vCode)
        {
            try
            {
                
                var iList = new List<Invoice>();
                if (cCode == "test" && vCode == "test")
                {
                    return Ok(iList);
                }
                if (vCode != "test")
                {
                    var vendor = _context.Vendors.Where(v => v.VendorCode == vCode).SingleOrDefault();
                    if (vendor != null)
                    {
                        iList = _context.Invoices.Where(i => i.VendorId == vendor.VendorId).ToList();
                    }
                    else
                    {
                        iList = _context.Invoices.ToList();
                    }
                }
                else
                {
                    iList = _context.Invoices.ToList();
                }
                
                if(cCode != "test")
                {
                    var currency = _context.Currencies.Where(v => v.CurrencyCode == cCode).SingleOrDefault();
                    if (currency != null)
                    {
                        iList = iList.Where(i => i.CurrencyId == currency.CurrencyId).ToList();
                    }
                }
                
                return Ok(iList);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpGet("countByVendorId")]
        public IActionResult GetAllInvoicesCountByVendorId()
        {
            try
            {
                var list = _context.Invoices.ToList().GroupBy(i => i.VendorId).Select(g => new { VendorId = g.Key, Count = g.Count() });
                return Ok(list);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpPost]
        public IActionResult AddInvoice([FromBody] InvoiceDto invoiceREF)
        {
            try
            {
                if (_context.Invoices.Any(c => c.InvoiceNumber == invoiceREF.InvoiceNumber))
                {
                    return BadRequest("There is already invoice with same number.");
                }

                if(_context.Vendors.Any(v => v.VendorId == invoiceREF.VendorId))
                {
                    var i = invoiceREF;
                    if(_context.Currencies.Any(c => c.CurrencyId == invoiceREF.CurrencyId))
                    {
                        //var vendor = _context.Vendors.Find(invoiceREF.VendorId);
                        var currency = _context.Currencies.Find(invoiceREF.CurrencyId);
                        var invoice = new Invoice()
                        {
                            InvoiceNumber = invoiceREF.InvoiceNumber,
                            CurrencyId = invoiceREF.CurrencyId,
                            VendorId = invoiceREF.VendorId,
                            InvoiceAmount = invoiceREF.InvoiceAmount,
                            InvoiceReceivedDate = DateTime.Now,
                            InvoiceDueDate = invoiceREF.InvoiceDueDate,
                            IsActive = true,
                            //vendor = vendor,
                            //currency = currency
                        };
                       

                        _context.Invoices.Add(invoice);
                        _context.SaveChanges();
                        IObservable<string> stringObservable = Observable.Return("Invoice Added successfully");
                        return Created("", stringObservable);
                    }
                    else
                    {
                        return NotFound("Currency not present");
                    }
                }
                else
                {
                    return NotFound("Vendor not present");
                }
               
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpPut("{iNumber}")]
        public IActionResult UpdateInvoice(int iNumber,[FromBody] InvoiceDto invoiceREF)
        {
            try
            {
                Invoice invoice = _context.Invoices.Where(c => c.InvoiceNumber == iNumber).SingleOrDefault();

                if (invoice == null)
                {
                    return NotFound("Vendor not found");
                }

                invoice.InvoiceNumber = invoiceREF.InvoiceNumber;
                invoice.CurrencyId = invoiceREF.CurrencyId;
                invoice.VendorId = invoiceREF.VendorId;
                invoice.InvoiceAmount = invoiceREF.InvoiceAmount;
                invoice.InvoiceDueDate = invoiceREF.InvoiceDueDate;
                invoice.IsActive = invoiceREF.IsActive;
                _context.Entry(invoice).State = EntityState.Modified;
                _context.SaveChanges();
                IObservable<string> stringObservable = Observable.Return("Invoice updated");
                return Accepted("", stringObservable);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        [HttpDelete("{iNumber}")]
        public IActionResult DeleteInvoice(int iNumber)
        {
            Invoice invoiceREF = _context.Invoices.Where(c => c.InvoiceNumber == iNumber).SingleOrDefault();
            if (invoiceREF == null)
            {
                return NotFound("invoice not found");
            }
            
            _context.Invoices.Remove(invoiceREF);
            _context.SaveChangesAsync();

            return NoContent();
        }

        //[HttpPost]
        //[Route("export")]
        //public IActionResult ExportInvoiceList()
        //{
        //    try
        //    {
        //        var msg = invoice.ExportInvoiceList();
        //        IObservable<string> stringObservable = Observable.Return(msg);
        //        return Ok(stringObservable);
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(ex.Message);
        //    }
        //}

    
}
}
