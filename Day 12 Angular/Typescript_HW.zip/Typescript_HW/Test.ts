import { Book } from "./Book";
import { Library } from "./Library";

let library: Library = new Library();

console.log(library.addBook(new Book("DSA", "ABC", "123dsa", 5)));
console.log(library.addBook(new Book("Angular", "XYZ", "dsa", 5)));
console.log(library.addBook(
    new Book(
      "The Pragmatic Programmer",
      "Andrew Hunt and David Thomas",
      "978-0201616224",
      1
    )
  ));
console.log(library.addBook(
    new Book("Clean Code", "Robert C. Martin", "978-0132350884", 2)
  ));
console.log(library.addBook(
    new Book(
      "Design Patterns: Elements of Reusable Object-Oriented Software",
      "Erich Gamma, Richard Helm, Ralph Johnson, and John Vlissides",
      "978-0201633610",
      1
    )
  ));

// library.addBook(new Book("Introduction to Algorithms", "Thomas H. Cormen, Charles E. Leiserson, Ronald L. Rivest, and Clifford Stein", "978-0262033848", 4));
// library.addBook(new Book("You Don't Know JS", "Kyle Simpson", "978-1491904244", 15));
// library.addBook(new Book("JavaScript: The Good Parts", "Douglas Crockford", "978-0596517748", 20));
// library.addBook(new Book("Effective Java", "Joshua Bloch", "978-0134685991", 1));
// library.addBook(new Book("The Art of Computer Programming", "Donald E. Knuth", "978-0201896831", 8));
// library.addBook(new Book("Sapiens: A Brief History of Humankind", "Yuval Noah Harari", "978-0062316097", 9));
// library.addBook(new Book("Educated", "Tara Westover", "978-0399590504", 11));


//removing book

console.log(library.removeBook("123dsa"));
// console.log(library.removeBook("123dsa")); // error message -- working

//find book by a title
let book = library.findBookByTitle("DSA");
if(book == undefined){
    console.log("Book not found!!!");
}else{
    console.log(`Book Title : ${book.title}, Book Author : ${book.author}, Book isbn : ${book.isbn}`);
}